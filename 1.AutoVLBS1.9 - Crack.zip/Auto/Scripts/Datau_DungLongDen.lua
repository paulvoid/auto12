-- File nay duoc dung trong phan Datau mo rong->tab KN/PD

szVulanLib = system.GetScriptFolder().."\\LIB\\VulanLib.lua"
IncludeFile(szVulanLib)
--------------------------
szItemName = "H�p qu� gi�ng sinh"
--------------------------
Use_hop_qua = function()
tbVulanLib.UseItemName()
end
--------------------------
function main()


	Use_hop_qua()


end