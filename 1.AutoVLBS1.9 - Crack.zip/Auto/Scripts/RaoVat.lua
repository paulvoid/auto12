szVulanLib = system.GetScriptFolder().."\\LIB\\VulanLib.lua"
IncludeFile(szVulanLib)
--------------------------
gl_AdMess = "Shop t�p h�a t�i t��ng d��ng 196 202 anh em gh� qua �ng h� n�o"
--------------------------
function main()
	while true do
		tbVulanLib.Chat("CH_WORLD",gl_AdMess )
		timer.Sleep(1000)
		tbVulanLib.Chat("CH_CITY",gl_AdMess )
		tbVulanLib.Chat("CH_NEARBY",gl_AdMess )
		timer.Sleep(60000)
	end
end