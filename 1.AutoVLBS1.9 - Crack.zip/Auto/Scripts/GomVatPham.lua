-- File nay duoc dung trong phan Datau mo rong->tab KN/PD

szVulanLib = system.GetScriptFolder().."\\LIB\\VulanLib.lua"
IncludeFile(szVulanLib)
--------------------------
szItemName = "K�o gi�ng sinh (b� x�u)"
--------------------------
Use_Long_Den = function()

	


		if tbVulanLib.UseAllItem(szItemName) == 0 then end --het vat pham



end
--------------------------
function main()


for i=0,255 do
	Use_Long_Den()

end
end